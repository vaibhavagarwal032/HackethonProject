package com.vaibhav.hackathon.Model;

public class User {

    private String admissionno;
    private String contact;
    private String course;
    private String name;
    private String password;

    public User() {
    }

    public User(String admissionno, String contact, String course, String name, String password) {
        this.admissionno = admissionno;
        this.contact = contact;
        this.course = course;
        this.name = name;
        this.password = password;
    }

    public String getAdmissionno() {
        return admissionno;
    }

    public void setAdmissionno(String admissionno) {
        this.admissionno = admissionno;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}