package com.vaibhav.hackathon.Model;

public class Department {
    private String name;
    private String emailid;
    private String Qualification;

    public Department() {
    }

    public Department(String name, String emailid, String qualification) {
        this.name = name;
        this.emailid = emailid;
        Qualification = qualification;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getQualification() {
        return Qualification;
    }

    public void setQualification(String qualification) {
        Qualification = qualification;
    }
}
