package com.vaibhav.hackathon;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Room extends AppCompatActivity {
    String fl;
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);

       // getSupportActionBar().setTitle("Room Location");

        txt=findViewById(R.id.data);

        Intent intent=getIntent();
        String block=intent.getStringExtra("block");
        String room=intent.getStringExtra("room");
        String floor=intent.getStringExtra("floor");

       switch(floor)

       {
           case "0":
               fl="Ground Floor";
               break;
           case "1":
               fl="First Floor";
               break;

           case "2":
               fl="Second Floor";
               break;

           case "3":
               fl="Third Floor";
               break;

           case "4":
               fl="Fourth Floor";
               break;

           case "5":
               fl="Fifth Floor";
               break;
           default:
               fl="Give Right Option";

       }


        txt.setText(block+" Block\n"+fl+"\nRoom no."+room);

    }
}
