package com.vaibhav.hackathon;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

public class HigherAuthority extends AppCompatActivity {
    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_higher_authority);


        toolbar = findViewById(R.id.activity_higher_app_bar_layout);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Higher Authority");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setTitleTextColor(Color.WHITE);

    }

    public void chairman(View view) {
startActivity(new Intent(getApplicationContext(),Chairman.class));
    }

    public void ceo(View view) {
       // setContentView(R.layout.activity_higher_authority);
        Toast.makeText(this, "CEO Detail", Toast.LENGTH_SHORT).show();

    }

    public void vice(View view) {
        Toast.makeText(this, "Vice Chancellor", Toast.LENGTH_SHORT).show();
    }

    public void registrar(View view) {
        Toast.makeText(this, "Registrar Details", Toast.LENGTH_SHORT).show();
         }
}
