package com.vaibhav.hackathon;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class MentorActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;
    private Spinner mentorInputSp;
    private Button viewMentorBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mentor);

        toolbar = findViewById(R.id.mentor_activity_app_bar_layout);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Search Mentor Office");
        toolbar.setTitleTextColor(Color.WHITE);

        mentorInputSp = findViewById(R.id.choose_for_finding_mentor_office);
        viewMentorBtn = findViewById(R.id.view_mentor);

        viewMentorBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == viewMentorBtn){
            //write the code here which extract the data from database for mentor
            Toast.makeText(this, "A Block - 105", Toast.LENGTH_SHORT).show();
        }
    }
}