package com.vaibhav.hackathon;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class ProgramChairActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;
    private Spinner programChairInputSp;
    private Button viewPCBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_program_chair);

        toolbar = findViewById(R.id.program_chair_activity_app_bar_layout);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Search Program Chair Office");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setTitleTextColor(Color.WHITE);

        programChairInputSp = findViewById(R.id.choose_for_finding_program_chair_office);
        viewPCBtn = findViewById(R.id.view_program_chair);

        viewPCBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == viewPCBtn){
            // write the code here which extract the data from database for Program Chair
            Toast.makeText(this, "A Block - 202", Toast.LENGTH_SHORT).show();
        }
    }
}