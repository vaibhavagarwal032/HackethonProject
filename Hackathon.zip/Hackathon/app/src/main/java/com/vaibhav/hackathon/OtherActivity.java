package com.vaibhav.hackathon;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class OtherActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;
    private Button medicalBtn;
    private Button accountBtn;
    private Button hostelBtn;
    private Button clubBtn;
    private Button eventBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);

        toolbar = findViewById(R.id.others_activity_app_bar_layout);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Others Content");
        toolbar.setTitleTextColor(Color.WHITE);

        medicalBtn = findViewById(R.id.medical_section);
        accountBtn = findViewById(R.id.account_section);
        hostelBtn = findViewById(R.id.hostel_life);
        clubBtn = findViewById(R.id.club);
        eventBtn = findViewById(R.id.event);

        medicalBtn.setOnClickListener(this);
        accountBtn.setOnClickListener(this);
        hostelBtn.setOnClickListener(this);
        clubBtn.setOnClickListener(this);
        eventBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == medicalBtn){
            Intent medicalIntent = new Intent(OtherActivity.this, MedicalActivity.class);
            startActivity(medicalIntent);
            Toast.makeText(this, "Medical Section", Toast.LENGTH_SHORT).show();
        }
        if (v == accountBtn){
            Intent accountIntent = new Intent(OtherActivity.this, AccountActivity.class);
            startActivity(accountIntent);
            Toast.makeText(this, "Account Section", Toast.LENGTH_SHORT).show();
        }
        if (v == hostelBtn){
            Intent hostelIntent = new Intent(OtherActivity.this, HostelActivity.class);
            startActivity(hostelIntent);
            Toast.makeText(this, "Hostel Life", Toast.LENGTH_SHORT).show();
        }
        if (v == clubBtn){
            Intent clubIntent = new Intent(OtherActivity.this, ClubActivity.class);
            startActivity(clubIntent);
            Toast.makeText(this, "Club Section", Toast.LENGTH_SHORT).show();
        }
        if (v == eventBtn){
            Toast.makeText(this, "Event Section", Toast.LENGTH_SHORT).show();
        }
    }
}