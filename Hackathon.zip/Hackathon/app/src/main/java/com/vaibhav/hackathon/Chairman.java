package com.vaibhav.hackathon;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toolbar;

public class Chairman extends AppCompatActivity {

    TextView txt;
    private android.support.v7.widget.Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chairman);



        toolbar = findViewById(R.id.activity_chairman_app_bar_layout);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Chairman Info");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setTitleTextColor(Color.WHITE);

        txt=(TextView)findViewById(R.id.text);
        txt.setText("Sunil Galgotia\n Cabin - 315\n Email id-sunilgalgotia@galgotiasuniversity.edu.in");


    }

}
