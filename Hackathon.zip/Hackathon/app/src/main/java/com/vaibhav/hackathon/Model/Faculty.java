package com.vaibhav.hackathon.Model;

public class Faculty {
}
