package com.vaibhav.hackathon.Common;

import com.vaibhav.hackathon.Model.User;

public class Common {
    public static User currentUser;
}
