package com.vaibhav.hackathon;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vaibhav.hackathon.Model.User;

public class MainActivity extends AppCompatActivity {

    TextInputEditText name,course,admissionno,contact,password;
    AppCompatButton signup;
    AppCompatTextView login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=findViewById(R.id.name);
        course=findViewById(R.id.course);
        admissionno=findViewById(R.id.admissionno);
        contact=findViewById(R.id.admissionno);
        password=findViewById(R.id.password);

        signup=findViewById(R.id.signup);
        login=findViewById(R.id.login);

        final FirebaseDatabase database=FirebaseDatabase.getInstance();
        final DatabaseReference table_user=database.getReference("User");

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent=new Intent(MainActivity.this,LoginActivity.class);
                startActivity(myintent);
            }
        });

        signup.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                final ProgressDialog mDialog=new ProgressDialog(MainActivity.this);
                mDialog.setMessage("Please Wait");
                mDialog.show();

                table_user.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.child(admissionno.getText().toString()).exists()){
                            mDialog.dismiss();
                            Toast.makeText(MainActivity.this, "User already registered", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            mDialog.dismiss();
                            User user=new User(admissionno.getText().toString(),contact.getText().toString(),course.getText().toString(),name.getText().toString(),password.getText().toString());
                            table_user.child(admissionno.getText().toString()).setValue(user);
                            Toast.makeText(MainActivity.this, "Registration Sucessfully done!!1", Toast.LENGTH_SHORT).show();
                            Intent myintent=new Intent(MainActivity.this,LoginActivity.class);
                            startActivity(myintent);
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });



    }

    public void classSearch(View view) {
        startActivity(new Intent(getApplicationContext(),ClassActivity.class));
    }
}
