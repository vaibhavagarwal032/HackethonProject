package com.vaibhav.hackathon;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class HomeActivity extends AppCompatActivity  {
    private Toolbar toolbar;
    private Button classBtn;
    private Button departmentBtn;
    private Button facultyBtn;
    private Button libraryBtn;
    private Button otherBtn;
    private Button authorityBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        toolbar = findViewById(R.id.activity_main_app_bar_layout);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Home");
        toolbar.setTitleTextColor(Color.WHITE);

        classBtn = findViewById(R.id.class_search);
        departmentBtn = findViewById(R.id.department_search);
        facultyBtn = findViewById(R.id.faculty_search);
        libraryBtn = findViewById(R.id.library);
        authorityBtn=findViewById(R.id.higher_authority);

        otherBtn = findViewById(R.id.other_search);

        classBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent=new Intent(HomeActivity.this,ClassActivity.class);
                startActivity(myintent);
            }
        });
        departmentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent=new Intent(HomeActivity.this,DepartmentActivity.class);
                startActivity(myintent);
            }
        });
        facultyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent= new Intent(HomeActivity.this,FacultyActivity.class);
                startActivity(myintent);
            }
        });
        libraryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent=new Intent(HomeActivity.this,LibraryActivity.class);
                startActivity(myintent);
            }
        });
        authorityBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent=new Intent(HomeActivity.this,HigherAuthority.class);
                startActivity(myintent);
            }
        });
        otherBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent =new Intent(HomeActivity.this,OtherActivity.class);
                startActivity(myintent);
            }
        });
    }


}

