package com.vaibhav.hackathon;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class DeanActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;
    private Spinner deanInputSp;
    private Button viewBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dean);

        toolbar = findViewById(R.id.dean_activity_app_bar_layout);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Search Dean Office");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setTitleTextColor(Color.WHITE);

        deanInputSp = findViewById(R.id.choose_for_finding_dean_office);
        viewBtn = findViewById(R.id.view_dean);

        viewBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == viewBtn){
            // write the code here for access the data from database for dean
            Toast.makeText(this, "A block - 305", Toast.LENGTH_SHORT).show();
        }
    }
}